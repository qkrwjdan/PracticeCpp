#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "object.h"
#include "CLinkedList.h"


int pwd(List * pathList);
int cd(List * pathList, char * name);

int main() {

    Folder obj1;
    memset(&obj1, 0, sizeof(Folder));
    Folder obj2;
    memset(&obj2, 0, sizeof(Folder));
    Folder obj3;
    memset(&obj3, 0, sizeof(Folder));
    Folder obj4;
    memset(&obj4, 0, sizeof(Folder));

    File obj5;
    memset(&obj4, 0, sizeof(Folder));

    printf("first step success\n");
    obj1.type = 'd';
    obj2.type = 'd';
    obj3.type = 'd';
    obj4.type = 'd';
    obj5.type = '-';

    obj1.ptr_array[0] = (struct Object *)&obj2;
    obj1.children++;
    obj2.ptr_array[0] = (struct Object *)&obj3;
    obj2.children++;
    obj3.ptr_array[0] = (struct Object *)&obj4;
    obj3.children++;
    obj4.ptr_array[0] = (struct Object *)&obj5;
    obj4.children++;

    printf("second step success\n");

    strcpy(obj1.name,"park");
    strcpy(obj2.name,"jeong");
    strcpy(obj3.name,"shin");
    strcpy(obj4.name,"kim");
    strcpy(obj5.name,"lsd");

    printf("third step success\n");

    List pathList;
    ListInit(&pathList);
//
//    LInsert(&pathList,&obj1);
//    LInsert(&pathList,&obj2);
//    LInsert(&pathList,&obj3);
//    now_folder = pathList.tail->data;
//    printf("\n%d\n",pwd(&pathList));
//
//    printf("%d",now_folder->children);
//    printf("%s",now_folder->name);

    LInsert(&pathList,&obj1);
    LInsert(&pathList,&obj2);
    LInsert(&pathList,&obj3);
    LInsert(&pathList,&obj4);

    printf("forth step success\n");

    pwd(&pathList);

    printf("%d\n",pathList.numOfData);

    printf("%s\n",pathList.tail->data->name);

    now_folder = pathList.tail->data;

    printf("%d\n",now_folder->children);

    printf("%s\n",now_folder->name);

    printf("fifth step success\n");

    pwd(&pathList);
    cd(&pathList,"..");
    pwd(&pathList);
    cd(&pathList,"..");
    pwd(&pathList);
    cd(&pathList,"shin");
    pwd(&pathList);
    printf("sixth step success\n");

    cd(&pathList,"kim");
    pwd(&pathList);
    cd(&pathList,"lsd");
    pwd(&pathList);
    cd(&pathList,"agsd");
    pwd(&pathList);

    printf("%s\n",now_folder->name);

    return 0;

}

int pwd(List * pathList){

    Node * ptr;
    ptr = pathList->head;

    printf("/");

    while(ptr != NULL){
        printf("%s/",ptr->data->name);
        ptr = ptr->next;
    }

    printf("\n");
    return 1;
}

int cd(List * pathList, char * name){

    if(name == ".."){
        LRemove(pathList);
        now_folder = pathList->tail->data;
        return 1;
    }
    else if(name == "."){

    }
    else if(name == "~"){

    }
    else if(name == "/"){

    }
    else{
        int childNum = now_folder->children;

        for(int i=0;i<childNum;i++){

            Folder * tmp = (Folder *)(now_folder->ptr_array[i]);

            if(strcmp(tmp->name,name) == 0){

                if(tmp->type == 'd') {
                    LInsert(pathList,tmp);
                    now_folder = pathList->tail->data;
                    return 1;
                }else{
                    printf("It is file\n");
                    return 0;
                }

            }
        }

        printf("here is no such file\n");
        return 0;
    }

}
