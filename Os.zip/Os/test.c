//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//
//#include "object.h"
//#include "CLinkedList.h"
//
//int main(void){
//    List testList;
//    ListInit(&testList);
//
//    for(int i=0;i<5;i++){
//        LInsert(&testList,i);
//        printf("before : %d\n",testList.before->data);
//        printf("head : %d\n",testList.head->data);
//        printf("tail : %d\n",testList.tail->data);
//    }
//
//    Node * ptr;
//    ptr = testList.head;
//
//    while(ptr != NULL){
//        printf("%d\n",ptr->data);
//        ptr = ptr->next;
//    }
//
//    for(int i=0;i<5;i++){
//        LRemove(&testList);
//    }
//
//    LInsert(&testList,1);
//    printf("before : %d\n",testList.before->data);
//    printf("head : %d\n",testList.head->data);
//    printf("tail : %d\n",testList.tail->data);
//    LInsert(&testList,2);
//    printf("before : %d\n",testList.before->data);
//    printf("head : %d\n",testList.head->data);
//    printf("tail : %d\n",testList.tail->data);
//    LInsert(&testList,3);
//    printf("before : %d\n",testList.before->data);
//    printf("head : %d\n",testList.head->data);
//    printf("tail : %d\n",testList.tail->data);
//    LRemove(&testList);
//    printf("before : %d\n",testList.before->data);
//    printf("head : %d\n",testList.head->data);
//    printf("tail : %d\n",testList.tail->data);
//    LRemove(&testList);
//    printf("before : %d\n",testList.before->data);
//    printf("head : %d\n",testList.head->data);
//    printf("tail : %d\n",testList.tail->data);
//    LRemove(&testList);
//    LRemove(&testList);
//
//    printf("success!\n");
//
//}