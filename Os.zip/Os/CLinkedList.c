#include <stdio.h>
#include <stdlib.h>
#include "CLinkedList.h"


void ListInit(List * plist){
    /*
     * 리스트를 초기화하는 함수.
     * 리스트를 생성한 뒤 꼭 해줘야 함
     */
    plist->numOfData = 0;
    plist->head = NULL;
    plist->tail = NULL;
    plist->before = NULL;
}

void LInsert(List * plist, Data data){
    /*
     * tail에 Data를 추가하는 함수.
     */

    Node * newNode = (Node*)malloc(sizeof(Node)); //동적할당
    newNode->data = data; //동적할당 후 초기화
    newNode->next = NULL;

    if(plist->tail == NULL){ // 첫번째 데이터를 넣을때.
        plist->tail = newNode;
        plist->head = newNode;
        plist->before = newNode;
    }
    else{ // 첫번째 이후(첫번째가 아닌 두,세번째....) 데이터를 넣을때.
        plist->tail->next = newNode;
        plist->before = plist->tail;
        plist->tail = newNode;
    }

    (plist->numOfData)++; //갯수 증가.
}

Data LRemove(List * plist){

    /*
     * tail을 삭제하는 함수.
     */

    if(plist->head == NULL){
        printf("There is No data\n");
        exit(111);
    }

    Node * rpos = plist->tail;
    Data rdata = rpos->data;

    if(plist->tail == plist->head){
        plist->head = NULL;
        plist->tail = NULL;
        plist->before = NULL;
    }
    else{
        plist->tail = plist->before;
        plist->before = plist->head;
        while(1){
            if((plist->before == plist->tail) || (plist->before->next == plist->tail))
                break;
            Node * tmp = plist->before;
            plist->before = tmp->next;

        }
        plist->tail->next = NULL;
    }


    free(rpos);
    (plist->numOfData)--;
    return rdata;
}

int LCount(List * plist){
    return plist->numOfData;
}